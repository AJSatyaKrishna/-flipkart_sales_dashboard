"""
Flipkart Republic Day Sale 2025 - Data Cleaning & EDA
Run after generate_data.py
"""

import pandas as pd
import numpy as np

# ── Load ──────────────────────────────────────────────────────────────────────
df = pd.read_csv("flipkart_sales_raw.csv")
print("Raw shape:", df.shape)

# ── 1. Basic Info ─────────────────────────────────────────────────────────────
print("\n--- Data Types ---")
print(df.dtypes)
print("\n--- Null Values ---")
print(df.isnull().sum())
print("\n--- Duplicates:", df.duplicated().sum())

# ── 2. Type Conversions ───────────────────────────────────────────────────────
df["sale_date"]  = pd.to_datetime(df["sale_date"])
df["sale_day"]   = df["sale_date"].dt.day_name()
df["sale_hour"]  = pd.to_datetime(df["sale_time"], format="%H:%M:%S").dt.hour
df["returned"]   = df["returned"].map({"Yes": 1, "No": 0})

# ── 3. Feature Engineering ────────────────────────────────────────────────────
df["net_revenue"]    = df.apply(lambda r: 0 if r["returned"] else r["revenue"], axis=1)
df["discount_amount"]= df["original_price"] - df["final_price"]
df["is_high_value"]  = (df["revenue"] > df["revenue"].quantile(0.75)).astype(int)

# ── 4. KPI Summary ────────────────────────────────────────────────────────────
print("\n======== KPI SUMMARY ========")
print(f"Total Revenue       : ₹{df['net_revenue'].sum():,.2f}")
print(f"Total Orders        : {len(df):,}")
print(f"Avg Order Value     : ₹{df['net_revenue'].mean():,.2f}")
print(f"Return Rate         : {df['returned'].mean()*100:.1f}%")
print(f"Top Category        : {df.groupby('category')['net_revenue'].sum().idxmax()}")
print(f"Top State           : {df.groupby('customer_state')['net_revenue'].sum().idxmax()}")
print(f"Most Used Payment   : {df['payment_method'].value_counts().idxmax()}")

# ── 5. Category Growth % (Day 1 vs Day 7) ─────────────────────────────────────
df["day_num"] = (df["sale_date"] - df["sale_date"].min()).dt.days + 1
day1 = df[df["day_num"]==1].groupby("category")["net_revenue"].sum()
day7 = df[df["day_num"]==7].groupby("category")["net_revenue"].sum()
growth = ((day7 - day1) / day1 * 100).round(1)
print("\n--- Category Growth % (Day 1 vs Day 7) ---")
print(growth.sort_values(ascending=False))

# ── 6. Top 10 Products ────────────────────────────────────────────────────────
top10 = df.groupby("product_name")["net_revenue"].sum().nlargest(10)
print("\n--- Top 10 Products by Revenue ---")
print(top10)

# ── 7. Save Clean Data ────────────────────────────────────────────────────────
df.to_csv("flipkart_sales_clean.csv", index=False)
print("\nClean data saved -> flipkart_sales_clean.csv")
