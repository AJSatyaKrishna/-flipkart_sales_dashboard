"""
Flipkart Republic Day Sale 2025 - Data Generator
Generates a realistic synthetic sales dataset for analysis
"""

import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta

np.random.seed(42)
random.seed(42)

CATEGORIES = {
    "Electronics":    ["Smartphone", "Laptop", "Tablet", "Smart TV", "Earbuds", "Smartwatch"],
    "Fashion":        ["T-Shirt", "Jeans", "Sneakers", "Dress", "Jacket", "Saree"],
    "Home & Kitchen": ["Mixer Grinder", "Pressure Cooker", "Bedsheet", "Air Fryer", "Vacuum Cleaner"],
    "Books":          ["Fiction Novel", "Self Help Book", "Textbook", "Comic Book"],
    "Sports":         ["Cricket Bat", "Yoga Mat", "Dumbbells", "Running Shoes", "Badminton Racket"],
    "Beauty":         ["Face Wash", "Moisturiser", "Lipstick", "Perfume", "Shampoo"],
}

STATES = ["Andhra Pradesh", "Telangana", "Maharashtra", "Karnataka", "Tamil Nadu",
          "Delhi", "Uttar Pradesh", "West Bengal", "Gujarat", "Rajasthan"]

PAYMENT_METHODS = ["UPI", "Credit Card", "Debit Card", "Net Banking", "EMI", "Cash on Delivery"]

rows = []
start_date = datetime(2025, 1, 19)   # Republic Day Sale starts

for i in range(50000):
    category = random.choice(list(CATEGORIES.keys()))
    product  = random.choice(CATEGORIES[category])

    base_price = {
        "Electronics": random.uniform(3000, 80000),
        "Fashion":      random.uniform(299,  3999),
        "Home & Kitchen": random.uniform(500, 15000),
        "Books":        random.uniform(99,   799),
        "Sports":       random.uniform(299,  8999),
        "Beauty":       random.uniform(99,   2499),
    }[category]

    discount_pct = random.choice([10, 20, 30, 40, 50, 60, 70])
    final_price  = round(base_price * (1 - discount_pct / 100), 2)
    quantity     = random.randint(1, 5)
    revenue      = round(final_price * quantity, 2)

    sale_date = start_date + timedelta(
        days=random.randint(0, 6),
        hours=random.randint(0, 23),
        minutes=random.randint(0, 59)
    )

    rows.append({
        "order_id":       f"FK{2025000000 + i}",
        "sale_date":      sale_date.strftime("%Y-%m-%d"),
        "sale_time":      sale_date.strftime("%H:%M:%S"),
        "category":       category,
        "product_name":   product,
        "original_price": round(base_price, 2),
        "discount_pct":   discount_pct,
        "final_price":    final_price,
        "quantity":       quantity,
        "revenue":        revenue,
        "payment_method": random.choice(PAYMENT_METHODS),
        "customer_state": random.choice(STATES),
        "rating":         round(random.uniform(3.0, 5.0), 1),
        "returned":       random.choices(["No", "Yes"], weights=[92, 8])[0],
    })

df = pd.DataFrame(rows)
df.to_csv("flipkart_sales_raw.csv", index=False)
print(f"Generated {len(df)} rows -> flipkart_sales_raw.csv")
print(df.head())
