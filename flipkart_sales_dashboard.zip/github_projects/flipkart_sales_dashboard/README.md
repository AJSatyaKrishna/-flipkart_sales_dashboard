# 📊 Flipkart Republic Day Sale 2025 — Sales Analytics Dashboard

> **Tools:** Python · SQL · Power BI · Excel · Pandas · Matplotlib · Seaborn

---

## 📌 Project Overview

An end-to-end sales analytics project analysing **50,000+ transaction records** from Flipkart's Republic Day Sale 2025. The project covers data generation, cleaning, exploratory data analysis (EDA), SQL querying, and Power BI dashboard development.

---

## 🎯 Key KPIs Delivered

| KPI | Description |
|-----|-------------|
| Total Revenue | Overall net revenue across all 7 sale days |
| Category Growth % | Revenue growth from Day 1 to Day 7 per category |
| Top 10 Products | Best performing products by revenue |
| Purchase Trends | Hourly and daily purchase volume patterns |
| Return Rate | % of orders returned per category |
| Payment Split | UPI vs Card vs COD breakdown |

---

## 📁 Project Structure

```
flipkart_sales_dashboard/
│
├── generate_data.py        # Synthetic dataset generator (50,000 rows)
├── data_cleaning.py        # Data cleaning, type conversion, feature engineering
├── eda_visualisation.py    # EDA + 8 chart outputs saved to /charts
├── sql_queries.sql         # 10 SQL queries (KPIs, window functions, CTEs)
├── charts/                 # Auto-generated PNG charts
└── README.md
```

---

## 🚀 How to Run

```bash
# Step 1 — Install dependencies
pip install pandas numpy matplotlib seaborn

# Step 2 — Generate dataset
python generate_data.py

# Step 3 — Clean data
python data_cleaning.py

# Step 4 — Run EDA and generate charts
python eda_visualisation.py

# Step 5 — Run SQL queries in MySQL Workbench
# Import flipkart_sales_clean.csv and run sql_queries.sql
```

---

## 📊 Sample Insights

- **Electronics** was the highest revenue category across all 7 days
- **UPI** was the most preferred payment method (~30% of orders)
- Peak purchase hours were **12 PM – 2 PM** and **8 PM – 10 PM**
- Average return rate was **~8%**, highest in Fashion category

---

## 👤 Author

**A J Satya Krishna**  
MBA Business Analytics | DNR College B.Sc CS  
📧 ajskrishna2003@gmail.com  
🔗 [LinkedIn](https://linkedin.com/in/jnaneswara-satya-krishna-arepalli)
