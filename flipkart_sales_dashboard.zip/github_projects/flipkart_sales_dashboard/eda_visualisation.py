"""
Flipkart Republic Day Sale 2025 - Full EDA & Visualisation
Generates charts saved as PNG files (Power BI import ready)
Run after data_cleaning.py
"""

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns
import os

os.makedirs("charts", exist_ok=True)

df = pd.read_csv("flipkart_sales_clean.csv", parse_dates=["sale_date"])
df["day_num"] = (df["sale_date"] - df["sale_date"].min()).dt.days + 1

sns.set_theme(style="whitegrid", palette="Blues_d")
BLUE = "#1B3A6B"
MID  = "#2E5DA6"

# ── 1. Daily Revenue Trend ────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(10, 4))
daily = df.groupby("sale_date")["net_revenue"].sum().reset_index()
ax.fill_between(daily["sale_date"], daily["net_revenue"], alpha=0.3, color=MID)
ax.plot(daily["sale_date"], daily["net_revenue"], color=BLUE, linewidth=2.5, marker="o")
ax.set_title("Daily Revenue Trend — Flipkart Republic Day Sale 2025", fontsize=13, fontweight="bold", color=BLUE)
ax.set_xlabel("Date"); ax.set_ylabel("Revenue (₹)")
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"₹{x/1e6:.1f}M"))
plt.tight_layout(); plt.savefig("charts/01_daily_revenue_trend.png", dpi=150); plt.close()
print("Saved: charts/01_daily_revenue_trend.png")

# ── 2. Revenue by Category ────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(9, 4))
cat_rev = df.groupby("category")["net_revenue"].sum().sort_values(ascending=True)
bars = ax.barh(cat_rev.index, cat_rev.values, color=MID, edgecolor="white")
ax.bar_label(bars, labels=[f"₹{v/1e6:.1f}M" for v in cat_rev.values], padding=5, fontsize=9)
ax.set_title("Total Revenue by Category", fontsize=13, fontweight="bold", color=BLUE)
ax.set_xlabel("Revenue (₹)")
ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"₹{x/1e6:.0f}M"))
plt.tight_layout(); plt.savefig("charts/02_revenue_by_category.png", dpi=150); plt.close()
print("Saved: charts/02_revenue_by_category.png")

# ── 3. Top 10 Products ────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(9, 4))
top10 = df.groupby("product_name")["net_revenue"].sum().nlargest(10).sort_values()
bars = ax.barh(top10.index, top10.values, color="#378ADD", edgecolor="white")
ax.bar_label(bars, labels=[f"₹{v/1e6:.2f}M" for v in top10.values], padding=4, fontsize=8)
ax.set_title("Top 10 Products by Revenue", fontsize=13, fontweight="bold", color=BLUE)
plt.tight_layout(); plt.savefig("charts/03_top10_products.png", dpi=150); plt.close()
print("Saved: charts/03_top10_products.png")

# ── 4. Payment Method Distribution ───────────────────────────────────────────
fig, ax = plt.subplots(figsize=(7, 4))
pay = df["payment_method"].value_counts()
colors = ["#1B3A6B","#2E5DA6","#378ADD","#85B7EB","#B5D4F4","#E6F1FB"]
wedges, texts, autotexts = ax.pie(pay.values, labels=pay.index, autopct="%1.1f%%",
                                   colors=colors, startangle=140)
for t in autotexts: t.set_fontsize(9)
ax.set_title("Payment Method Split", fontsize=13, fontweight="bold", color=BLUE)
plt.tight_layout(); plt.savefig("charts/04_payment_method.png", dpi=150); plt.close()
print("Saved: charts/04_payment_method.png")

# ── 5. Revenue by State (Heatmap-style bar) ───────────────────────────────────
fig, ax = plt.subplots(figsize=(9, 4))
state_rev = df.groupby("customer_state")["net_revenue"].sum().sort_values(ascending=True)
norm = plt.Normalize(state_rev.min(), state_rev.max())
colors_map = plt.cm.Blues(norm(state_rev.values))
ax.barh(state_rev.index, state_rev.values, color=colors_map, edgecolor="white")
ax.set_title("Revenue by Customer State", fontsize=13, fontweight="bold", color=BLUE)
ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"₹{x/1e6:.0f}M"))
plt.tight_layout(); plt.savefig("charts/05_revenue_by_state.png", dpi=150); plt.close()
print("Saved: charts/05_revenue_by_state.png")

# ── 6. Hourly Purchase Trends ─────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(10, 4))
hourly = df.groupby("sale_hour")["order_id"].count()
ax.fill_between(hourly.index, hourly.values, alpha=0.25, color=MID)
ax.plot(hourly.index, hourly.values, color=BLUE, linewidth=2, marker="o", markersize=5)
ax.set_title("Hourly Purchase Volume (All 7 Days)", fontsize=13, fontweight="bold", color=BLUE)
ax.set_xlabel("Hour of Day"); ax.set_ylabel("Number of Orders")
ax.set_xticks(range(0, 24))
plt.tight_layout(); plt.savefig("charts/06_hourly_trend.png", dpi=150); plt.close()
print("Saved: charts/06_hourly_trend.png")

# ── 7. Discount vs Revenue Scatter ────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(8, 4))
sample = df.sample(2000, random_state=42)
ax.scatter(sample["discount_pct"], sample["net_revenue"], alpha=0.3, color=MID, s=15)
ax.set_title("Discount % vs Revenue per Order", fontsize=13, fontweight="bold", color=BLUE)
ax.set_xlabel("Discount %"); ax.set_ylabel("Revenue (₹)")
plt.tight_layout(); plt.savefig("charts/07_discount_vs_revenue.png", dpi=150); plt.close()
print("Saved: charts/07_discount_vs_revenue.png")

# ── 8. Category Growth % Day1 vs Day7 ────────────────────────────────────────
fig, ax = plt.subplots(figsize=(9, 4))
day1 = df[df["day_num"]==1].groupby("category")["net_revenue"].sum()
day7 = df[df["day_num"]==7].groupby("category")["net_revenue"].sum()
growth = ((day7 - day1) / day1 * 100).sort_values()
bar_colors = ["#E24B4A" if v < 0 else MID for v in growth.values]
ax.barh(growth.index, growth.values, color=bar_colors, edgecolor="white")
ax.axvline(0, color="gray", linewidth=0.8)
ax.set_title("Category Growth % — Day 1 vs Day 7", fontsize=13, fontweight="bold", color=BLUE)
ax.set_xlabel("Growth %")
plt.tight_layout(); plt.savefig("charts/08_category_growth.png", dpi=150); plt.close()
print("Saved: charts/08_category_growth.png")

print("\nAll 8 charts saved to ./charts/ folder")
print("Import flipkart_sales_clean.csv into Power BI for full dashboard!")
