-- ============================================================
-- Flipkart Republic Day Sale 2025 — SQL Analysis Queries
-- Run these on flipkart_sales_clean.csv imported into MySQL
-- Table name: flipkart_sales
-- ============================================================

-- ── TABLE SETUP ──────────────────────────────────────────────
CREATE DATABASE IF NOT EXISTS flipkart_analysis;
USE flipkart_analysis;

CREATE TABLE IF NOT EXISTS flipkart_sales (
    order_id        VARCHAR(20) PRIMARY KEY,
    sale_date       DATE,
    sale_time       TIME,
    category        VARCHAR(50),
    product_name    VARCHAR(100),
    original_price  DECIMAL(10,2),
    discount_pct    INT,
    final_price     DECIMAL(10,2),
    quantity        INT,
    revenue         DECIMAL(10,2),
    payment_method  VARCHAR(30),
    customer_state  VARCHAR(50),
    rating          DECIMAL(3,1),
    returned        TINYINT,
    net_revenue     DECIMAL(10,2),
    discount_amount DECIMAL(10,2),
    is_high_value   TINYINT,
    day_num         INT,
    sale_hour       INT
);

-- ── Q1: TOTAL KPIs ───────────────────────────────────────────
SELECT
    COUNT(*)                        AS total_orders,
    ROUND(SUM(net_revenue), 2)      AS total_revenue,
    ROUND(AVG(net_revenue), 2)      AS avg_order_value,
    ROUND(SUM(returned) * 100.0
          / COUNT(*), 2)            AS return_rate_pct,
    ROUND(AVG(rating), 2)           AS avg_rating
FROM flipkart_sales;

-- ── Q2: REVENUE BY CATEGORY (sorted) ─────────────────────────
SELECT
    category,
    COUNT(*)                        AS total_orders,
    ROUND(SUM(net_revenue), 2)      AS total_revenue,
    ROUND(AVG(discount_pct), 1)     AS avg_discount_pct,
    ROUND(AVG(rating), 2)           AS avg_rating
FROM flipkart_sales
GROUP BY category
ORDER BY total_revenue DESC;

-- ── Q3: TOP 10 PRODUCTS BY REVENUE ───────────────────────────
SELECT
    product_name,
    category,
    COUNT(*)                    AS orders,
    ROUND(SUM(net_revenue), 2)  AS revenue,
    ROUND(AVG(final_price), 2)  AS avg_price
FROM flipkart_sales
GROUP BY product_name, category
ORDER BY revenue DESC
LIMIT 10;

-- ── Q4: DAILY REVENUE TREND ───────────────────────────────────
SELECT
    sale_date,
    day_num,
    COUNT(*)                        AS orders,
    ROUND(SUM(net_revenue), 2)      AS daily_revenue,
    ROUND(AVG(net_revenue), 2)      AS avg_order_value
FROM flipkart_sales
GROUP BY sale_date, day_num
ORDER BY sale_date;

-- ── Q5: CATEGORY GROWTH % (Day 1 vs Day 7) ───────────────────
WITH day1 AS (
    SELECT category, SUM(net_revenue) AS rev_day1
    FROM flipkart_sales WHERE day_num = 1
    GROUP BY category
),
day7 AS (
    SELECT category, SUM(net_revenue) AS rev_day7
    FROM flipkart_sales WHERE day_num = 7
    GROUP BY category
)
SELECT
    d1.category,
    ROUND(d1.rev_day1, 2)                              AS day1_revenue,
    ROUND(d7.rev_day7, 2)                              AS day7_revenue,
    ROUND((d7.rev_day7 - d1.rev_day1)
          / d1.rev_day1 * 100, 1)                      AS growth_pct
FROM day1 d1
JOIN day7 d7 ON d1.category = d7.category
ORDER BY growth_pct DESC;

-- ── Q6: PAYMENT METHOD BREAKDOWN ─────────────────────────────
SELECT
    payment_method,
    COUNT(*)                        AS orders,
    ROUND(SUM(net_revenue), 2)      AS total_revenue,
    ROUND(COUNT(*) * 100.0
          / (SELECT COUNT(*) FROM flipkart_sales), 2)  AS pct_orders
FROM flipkart_sales
GROUP BY payment_method
ORDER BY orders DESC;

-- ── Q7: REVENUE BY STATE ──────────────────────────────────────
SELECT
    customer_state,
    COUNT(*)                    AS orders,
    ROUND(SUM(net_revenue), 2)  AS total_revenue,
    ROUND(AVG(net_revenue), 2)  AS avg_order_value
FROM flipkart_sales
GROUP BY customer_state
ORDER BY total_revenue DESC;

-- ── Q8: HOURLY PURCHASE PATTERNS ──────────────────────────────
SELECT
    sale_hour,
    COUNT(*)                    AS orders,
    ROUND(SUM(net_revenue), 2)  AS revenue
FROM flipkart_sales
GROUP BY sale_hour
ORDER BY sale_hour;

-- ── Q9: HIGH VALUE vs LOW VALUE ORDER COMPARISON ─────────────
SELECT
    is_high_value,
    COUNT(*)                    AS orders,
    ROUND(SUM(net_revenue), 2)  AS total_revenue,
    ROUND(AVG(discount_pct), 1) AS avg_discount,
    ROUND(AVG(rating), 2)       AS avg_rating,
    ROUND(SUM(returned) * 100.0
          / COUNT(*), 2)        AS return_rate_pct
FROM flipkart_sales
GROUP BY is_high_value;

-- ── Q10: ROLLING 3-DAY REVENUE (Window Function) ─────────────
SELECT
    sale_date,
    ROUND(SUM(net_revenue), 2) AS daily_revenue,
    ROUND(AVG(SUM(net_revenue)) OVER (
        ORDER BY sale_date
        ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
    ), 2) AS rolling_3day_avg
FROM flipkart_sales
GROUP BY sale_date
ORDER BY sale_date;
